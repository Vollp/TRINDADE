/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p01.pkg01182000;

import java.util.Scanner;

public class P0101182000 {

    public static void main(String[] args) {
        /**
         * De acordo com o evento de games BGS, crie um programa que pergunte
         * qual o nome da pessoa, qual é sua idade e quantos ingressos serão
         * comprados para determinar o valor total a ser pago e exiba o valor
         * total a ser pago, a idade, o valor do ingresso e o nome.Sendo que até
         * 17 a entrada é R$5,50 e de 18 pra cima a entrada é R$10,30.
         */
        Scanner Leitor = new Scanner(System.in);

        System.out.println("Qual é seu nome?");
        String nome = Leitor.nextLine();
        System.out.println("Qual é a sua idade?");
        int idade = Leitor.nextInt();
        System.out.println("Quantos ingressos deseja comprar?");
        int quant = Leitor.nextInt();
        double meia = 5.50;
        double inteira = 10.30;

        if (idade < 18) {
            System.out.println(nome + "\nVocê comprou " + quant + " ingressos no valor de R$ " + meia + "\nO valor total a ser pago é de R$ " + (meia * quant));
        } else {
            System.out.println(nome + "\nVocê comprou " + quant + " ingressos no valor de R$ " + inteira + "\nO valor total a ser pago é de R$ " + (inteira * quant));
        }

    }

}
