package com.mycompany.auladeoshi;

    import oshi.SystemInfo;
    import oshi.hardware.CentralProcessor;
    import oshi.hardware.HardwareAbstractionLayer;
    import oshi.software.os.FileSystem;
    import oshi.software.os.OperatingSystemVersion;
    import oshi.util.FormatUtil;
    import oshi.hardware.Disks;
    import java.text.DecimalFormat;
import oshi.PlatformEnum;

public class MeuColetor {
    //FormatUtil.formatBytes
    public static void main(String[] args) {
        SystemInfo sistema = new SystemInfo();
        
        PlatformEnum nomeSistema = SystemInfo.getCurrentPlatformEnum();
        
        String processadorNome = sistema.getHardware().getProcessor().getName();
        
        long totalRAM = sistema.getHardware().getMemory().getTotal();
        
        long RAMUsada = sistema.getHardware().getMemory().getAvailable();
        
        int RAM = (int) ((RAMUsada * 100) / totalRAM);
        
        double cpu = sistema.getHardware().getProcessor().getSystemCpuLoadBetweenTicks();
        
        double cpu1 = cpu * 1000;
        DecimalFormat df = new DecimalFormat();
        df.applyPattern("###,00%");
        
        System.out.println("O sistema operacional que esta sendo utilizado é: " + nomeSistema);
        System.out.println("O processador da máquina é: " + processadorNome);
        System.out.println("Você esta utilizando " + RAM + "% de sua memória RAM");
        System.out.println("Você está utilizando " + df.format(cpu1) + " de sua CPU");
    }
    
}
